# turboc-mode13
bitmap scaling and blur
