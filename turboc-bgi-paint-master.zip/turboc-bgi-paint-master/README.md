# turboc-bgi-paint
paint program using turbo c bgi
